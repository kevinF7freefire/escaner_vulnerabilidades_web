#!/bin/bash
clear
echo "🧪 Lanzando UltraScan v3..."
chmod +x ultra-scan.sh
./ultra-scan.sh

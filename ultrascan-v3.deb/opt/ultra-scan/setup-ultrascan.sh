#!/bin/bash
sudo apt update
sudo apt install nmap nikto whatweb gobuster sqlmap sslyze wpscan curl -y
echo "📁 Estructura creada. Edita .env y ejecuta ./ultra-scan.sh"

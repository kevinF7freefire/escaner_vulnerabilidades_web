#!/bin/bash
# ╔════════════════════════════════════════════╗
# ║        UltraScan v3 - Curso Ético         ║
# ║   Escaneo automatizado + Telegram Bot     ║
# ╚════════════════════════════════════════════╝

DATE=$(date +%d-%m-%Y-%H%M)
OUTPUT="/opt/ultra-scan/resultados-$DATE"
mkdir -p "$OUTPUT"

source /opt/ultra-scan/.env
HTML="$WEB_PATH/reporte-$DATE.html"
mkdir -p "$WEB_PATH"

# 🎯 Validación de entrada
read -p "$(tput setaf 6)🌐 Ingresa el objetivo (ej. https://tusitio.com o IP): $(tput sgr0)" TARGET
if [[ -z "$TARGET" ]]; then echo "$(tput setaf 1)❌ Error: objetivo vacío$(tput sgr0)"; exit 1; fi

# 🔐 Validación del token
if ! curl -s "https://api.telegram.org/bot$BOT_TOKEN/getMe" | grep -q '"ok":true'; then
  echo "$(tput setaf 1)❌ BOT_TOKEN inválido o no autorizado$(tput sgr0)"
  exit 1
fi

# 🧠 Extraer dominio limpio para Nmap
HOST=$(echo "$TARGET" | sed -E 's@https?://([^/]+).*@\1@')

# 📋 Función de log
log() {
  local msg="[$(date +'%H:%M:%S')] $1"
  echo "$(tput setaf 2)$msg$(tput sgr0)" | tee -a "$OUTPUT/log.txt"
}

# 📬 Telegram
enviar_telegram () {
  curl -s -X POST https://api.telegram.org/bot$BOT_TOKEN/sendMessage \
  -d chat_id=$CHAT_ID -d text="$1"
}

# 🚨 Solo vulnerabilidades
enviar_vulnerabilidades () {
  local vulns=$(grep -Ei "vulnerab|critical|high|sql|xss|shell|exploit|injection" "$OUTPUT"/*.txt)
  curl -s -X POST https://api.telegram.org/bot$BOT_TOKEN/sendMessage \
  -d chat_id=$CHAT_ID -d text="🚨 Vulnerabilidades detectadas:\n${vulns:0:4000}"
}

# 🛠️ Comandos desde Telegram
verificar_comando () {
  local cmd=$(curl -s "https://api.telegram.org/bot$BOT_TOKEN/getUpdates" | grep -oP '"text":"\/[a-zA-Z0-9_]+"' | tail -1 | tr -d '"text":/')
  case $cmd in
    /estado) enviar_telegram "📊 Estado actual:\n$(tail -n 5 "$OUTPUT/log.txt")" ;;
    /detener) enviar_telegram "🛑 Escaneo detenido por comando remoto"; exit 0 ;;
    /repetir_nmap) ejecutar 1 ;;
    /reporte) curl -s -X POST "https://api.telegram.org/bot$BOT_TOKEN/sendDocument" \
      -F chat_id=$CHAT_ID -F document=@"$HTML" ;;
  esac
}

# 🧪 Menú interactivo
echo "$(tput setaf 3)🧪 Herramientas disponibles:$(tput sgr0)"
echo "1. Nmap     2. Nikto     3. WhatWeb"
echo "4. Gobuster 5. Sqlmap    6. SSLyze"
echo "7. Wpscan   8. Todas"
read -p "$(tput setaf 6)Selecciona (ej. 1 3 5 o 8): $(tput sgr0)" OPCIONES

log "🚀 Iniciando escaneo de $TARGET"
enviar_telegram "🚀 Escaneo iniciado: $TARGET"

# 🔄 Ejecución modular
ejecutar() {
  verificar_comando
  case $1 in
    1) log "🔍 Nmap"; nmap -sV -oN "$OUTPUT/nmap.txt" "$HOST"; log "✅ Nmap finalizado" ;;
    2) log "🔍 Nikto"; nikto -h "$TARGET" -output "$OUTPUT/nikto.txt"; log "✅ Nikto finalizado" ;;
    3) log "🔍 WhatWeb"; whatweb "$TARGET" > "$OUTPUT/whatweb.txt"; log "✅ WhatWeb finalizado" ;;
    4) log "🔍 Gobuster"; gobuster dir -u "$TARGET" -w /usr/share/wordlists/dirb/common.txt -o "$OUTPUT/gobuster.txt"; log "✅ Gobuster finalizado" ;;
    5) log "🔍 Sqlmap"; sqlmap -u "$TARGET" --batch > "$OUTPUT/sqlmap.txt"; log "✅ Sqlmap finalizado" ;;
    6) log "🔍 SSLyze"; sslyze --regular "$TARGET" > "$OUTPUT/sslyze.txt"; log "✅ SSLyze finalizado" ;;
    7) log "🔍 Wpscan"; wpscan --url "$TARGET" --no-update > "$OUTPUT/wpscan.txt"; log "✅ Wpscan finalizado" ;;
    8) for i in {1..7}; do ejecutar $i; done ;;
  esac
}

for opcion in $OPCIONES; do ejecutar $opcion; done

# 🌐 Generar HTML
echo "<html><head><title>Reporte UltraScan</title></head><body><h1>Escaneo de $TARGET</h1>" > "$HTML"
for file in "$OUTPUT"/*.txt; do
  echo "<h2>$(basename $file)</h2><pre>$(cat $file)</pre><hr>" >> "$HTML"
done
echo "</body></html>" >> "$HTML"
log "📄 Reporte HTML generado en $HTML"

enviar_vulnerabilidades
enviar_telegram "✅ Escaneo finalizado. Usa /reporte para recibir el HTML."
